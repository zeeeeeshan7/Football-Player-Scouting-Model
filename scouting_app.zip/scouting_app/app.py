
# ------------------------------------------------------------
# Scouting Model — Detailed Positions + Twitter Sentiment
# Uses snscrape (no API keys) and NLTK VADER to score sentiment.
# ------------------------------------------------------------
import os, datetime as dt
from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
import streamlit as st
from sklearn.preprocessing import MinMaxScaler
from dotenv import load_dotenv
load_dotenv()

# Load token once from .env
if "bearer_token" not in st.session_state or not st.session_state["bearer_token"]:
    import os
    st.session_state["bearer_token"] = os.getenv("TWITTER_BEARER_TOKEN", "")

# Sentiment deps
try:
    import nltk
    from nltk.sentiment import SentimentIntensityAnalyzer
except Exception as _e:
    nltk = None
    SentimentIntensityAnalyzer = None

# snscrape for X (Twitter) without API keys
try:
    import snscrape.modules.twitter as sntwitter
except Exception as _e:
    sntwitter = None

# Tweepy for official Twitter API v2 (bearer token)
try:
    import tweepy
except Exception as _e:
    tweepy = None

st.set_page_config(page_title="Scouting Model", page_icon="⚽", layout="wide")

# ------------------ Style ------------------
CSS = """
<style>
.main .block-container {padding-top: 1.2rem; max-width: 1200px;}
div[data-testid="stSidebar"] {background: #0b2f1f;}
.pitch-band {
  background: linear-gradient(135deg, #0b5d3b 0%, #0f7f54 100%);
  color: white; padding: 14px 18px; border-radius: 16px; margin-bottom: 14px;
  box-shadow: 0 8px 24px rgba(0,0,0,.16);
}
.badge {display:inline-block;background:#0f7f54;color:#fff;padding:2px 8px;border-radius:999px;font-size:12px;margin-left:8px;}
.card {background:#0f172a10;border:1px solid #e5e7eb;border-radius:16px;padding:16px;margin-bottom:12px;}
hr{border:none;border-top:1px solid #e5e7eb;margin:10px 0;}
.small{opacity:.8;font-size:12px}
.warn{background:#fff7ed;border:1px solid #fdba74;padding:8px 12px;border-radius:10px;margin-top:8px;}
.kpi{display:inline-block;min-width:110px;padding:8px 10px;border-radius:12px;border:1px solid #e5e7eb;margin-right:8px;margin-top:6px;}
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
np.random.seed(7)

# ------------------ Positions & Archetypes ------------------
DETAILED_POSITIONS = ["GK","LB","CB","RB","LWB","RWB","DM","CM","AM","LW","RW","ST","CF"]
SUBPOS_TO_GROUP = {
    "GK":"GK","LB":"DF","CB":"DF","RB":"DF","LWB":"DF","RWB":"DF",
    "DM":"MF","CM":"MF","AM":"MF","LW":"FW","RW":"FW","ST":"FW","CF":"FW"
}
ARCHETYPES_BY_SUBPOS = {
    "GK": ["Shot-Stopper", "Sweeper", "Ball-Playing GK"],
    "CB": ["Ball-Playing CB", "Stopper CB"],
    "LB": ["Offensive FB", "Defensive FB", "Wing-Back"],
    "RB": ["Offensive FB", "Defensive FB", "Wing-Back"],
    "LWB": ["Wing-Back"],
    "RWB": ["Wing-Back"],
    "DM": ["Destroyer", "Regista"],
    "CM": ["Box-to-Box", "Regista"],
    "AM": ["Playmaker AM"],
    "LW": ["Winger", "Inside Forward", "Wide Playmaker"],
    "RW": ["Winger", "Inside Forward", "Wide Playmaker"],
    "ST": ["Poacher", "Target Man", "Deep-Lying Forward"],
    "CF": ["Deep-Lying Forward", "Poacher"]
}
TRAITS_BY_ARCH = {
    # GK
    "Shot-Stopper": ["Save%", "Post-Shot xG Saved", "Reflexes"],
    "Sweeper": ["Def Actions Outside Area/90", "Exits/90", "Sweeps Won%"],
    "Ball-Playing GK": ["Pass Completion%", "Long Pass Acc%", "Launches/90"],
    # DF
    "Ball-Playing CB": ["Pass Completion%", "Progressive Passes/90", "Long Pass Acc%"],
    "Stopper CB": ["Aerial Win%", "Tackles/90", "Interceptions/90"],
    "Offensive FB": ["Progressive Carries/90", "Crosses/90", "Key Passes/90"],
    "Defensive FB": ["Tackles Won/90", "Blocks/90", "1v1 Def Success%"],
    "Wing-Back": ["Carries into Final 3rd/90", "Crosses/90", "xAG/90"],
    # MF
    "Regista": ["Progressive Passes/90", "Key Passes/90", "Pass Completion%"],
    "Box-to-Box": ["Pressures/90", "Tackles+Interceptions/90", "xG+xAG/90"],
    "Destroyer": ["Tackles Won/90", "Pressures/90", "Blocks/90"],
    "Playmaker AM": ["xAG/90", "Key Passes/90", "Through Balls/90"],
    "Wide Playmaker": ["Progressive Carries/90", "Crosses/90", "xAG/90"],
    # FW
    "Poacher": ["xG/90", "Shots/90", "Touches in Box/90"],
    "Target Man": ["Aerial Win%", "Hold-Up Wins/90", "Shots on Target%"],
    "Inside Forward": ["xG/90", "xAG/90", "Progressive Carries/90"],
    "Winger": ["Crosses/90", "Take-ons Won/90", "xAG/90"],
    "Deep-Lying Forward": ["Key Passes/90", "xAG/90", "Pass Completion%"]
}
DEFAULT_NUMERIC_FEATURES = list(set(sum(TRAITS_BY_ARCH.values(), [])))

# ------------------ Data loading ------------------
def _load_or_demo(filename: str, default_group: str) -> pd.DataFrame:
    path = os.path.join(DATA_DIR, filename)
    if os.path.exists(path):
        try:
            df = pd.read_excel(path)
            df.columns = [str(c).strip() for c in df.columns]
            if "Player" not in df.columns:
                for alt in ["Name", "player", "PLAYER", "Player Name"]:
                    if alt in df.columns:
                        df = df.rename(columns={alt: "Player"})
                        break
            if "Position" not in df.columns:
                df["Position"] = default_group
            if "Age" not in df.columns:
                df["Age"] = np.random.randint(18, 35, len(df))
            if "Value" not in df.columns:
                df["Value"] = np.random.randint(1_000_000, 30_000_000, len(df))
            return df
        except Exception as e:
            st.warning(f"Failed to read {filename}: {e}. Using demo data.")
    n = 20
    base = {
        "Player": [f"{default_group} Player {i+1}" for i in range(n)],
        "Position": default_group,
        "Age": np.random.randint(18, 34, n),
        "Value": np.random.randint(1_000_000, 25_000_000, n),
    }
    for col in DEFAULT_NUMERIC_FEATURES:
        base[col] = np.abs(np.random.randn(n) * 10 + 50)
    return pd.DataFrame(base)

def load_all() -> Dict[str, pd.DataFrame]:
    return {"GK": _load_or_demo("gk.xlsx","GK"),
            "DF": _load_or_demo("df.xlsx","DF"),
            "MF": _load_or_demo("mf.xlsx","MF"),
            "FW": _load_or_demo("fw.xlsx","FW")}

# ------------------ Ranking ------------------
def score_players(df: pd.DataFrame, traits: List[str], weights: Optional[List[float]]=None) -> pd.DataFrame:
    if not traits:
        df = df.copy()
        df["Score"] = 0.0
        return df
    X = df.copy()
    keep = ["Player", "Age", "Position", "Value"] + [c for c in traits if c in X.columns]
    X = X[[c for c in keep if c in X.columns]].copy()
    present = [t for t in traits if t in X.columns]
    if not present:
        X["Score"] = 0.0
        return X
    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(X[present].fillna(0.0))
    if weights is None or len(weights) != len(present):
        weights = np.ones(len(present))
    weights = np.array(weights) / (np.sum(weights) if np.sum(weights) else 1)
    X["Score"] = (scaled * weights).sum(axis=1)
    return X.sort_values("Score", ascending=False)

# ------------------ Sentiment ------------------
@st.cache_resource(show_spinner=False)
def _get_sia():
    """Initialize NLTK VADER sentiment analyzer safely."""
    try:
        import ssl
        import nltk
        from nltk.sentiment import SentimentIntensityAnalyzer

        # Allow SSL download in restricted environments
        try:
            _create_unverified_https_context = ssl._create_unverified_context
            ssl._create_default_https_context = _create_unverified_https_context
        except Exception:
            pass

        try:
            nltk.data.find("sentiment/vader_lexicon.zip")
        except LookupError:
            nltk.download("vader_lexicon")

        return SentimentIntensityAnalyzer()
    except Exception as e:
        st.warning(f"Could not initialize VADER: {e}")
        return None


def fetch_tweets(query: str, limit: int = 80, days: int = 7) -> List[str]:
    token = st.session_state.get("bearer_token", "").strip()
    if not token:
        raise RuntimeError("Missing Twitter Bearer Token. Paste it in the 'Bearer Token' box.")
    if tweepy is None:
        raise RuntimeError("tweepy is not installed. Please install requirements.txt again.")
    client = tweepy.Client(bearer_token=token, wait_on_rate_limit=True)
    start_time = (dt.datetime.utcnow() - dt.timedelta(days=days)).isoformat(timespec='seconds') + 'Z'
    q = f'\"{query}\" lang:en -is:retweet -is:reply -has:links'
    resp = client.search_recent_tweets(query=q, start_time=start_time, max_results=min(100, max(10, limit)), tweet_fields=["created_at","lang"])
    texts = []
    if resp and resp.data:
        for tw in resp.data[:limit]:
            txt = getattr(tw, "text", "") or ""
            if txt: texts.append(txt)
    return texts
def sentiment_summary(texts: List[str]) -> Tuple[float,int,dict]:
    sia = _get_sia()
    if sia is None or not texts:
        return (0.0, 0, {"pos":0.0,"neu":0.0,"neg":0.0})
    scores = [sia.polarity_scores(t) for t in texts]
    if not scores:
        return (0.0, 0, {"pos":0.0,"neu":0.0,"neg":0.0})
    comp = np.mean([s["compound"] for s in scores])
    pos = float(np.mean([s["pos"] for s in scores]))
    neu = float(np.mean([s["neu"] for s in scores]))
    neg = float(np.mean([s["neg"] for s in scores]))
    return (float(comp), len(texts), {"pos":pos,"neu":neu,"neg":neg})

def show_sentiment(player_name: str):
    st.write("##### Twitter (X) Sentiment — last 7 days")
    with st.spinner("Fetching tweets via Twitter API..."):
        try:
            tweets = fetch_tweets(player_name, limit=120, days=7)
        except Exception as e:
            st.markdown(f'<div class="warn">Twitter API error: {str(e)}</div>', unsafe_allow_html=True)
            return
    comp, n, dist = sentiment_summary(tweets)
    if n == 0:
        st.markdown('<div class="warn">Couldn\'t fetch tweets right now (rate limit / network). Try again later or different name.</div>', unsafe_allow_html=True)
        return
    label = "Positive" if comp >= 0.05 else ("Negative" if comp <= -0.05 else "Neutral")
    st.markdown(f"""
<div class="kpi"><b>Score</b><br>{comp:.3f} ({label})</div>
<div class="kpi"><b>Tweets</b><br>{n}</div>
<div class="kpi"><b>Pos</b><br>{dist['pos']:.2f}</div>
<div class="kpi"><b>Neu</b><br>{dist['neu']:.2f}</div>
<div class="kpi"><b>Neg</b><br>{dist['neg']:.2f}</div>
""", unsafe_allow_html=True)

    # Show a few sample tweets
    st.write("###### Recent mentions")
    for t in tweets[:5]:
        st.write(f"- {t}")

# ------------------ UI ------------------
def header():
    st.markdown('<div class="pitch-band"><h2 style="margin:0">⚽ Scouting Model</h2><div class="small">Detailed positions + sentiment</div></div>', unsafe_allow_html=True)

def welcome():
    st.write("### Welcome to the Scouting Model")
    st.write("Press the button below to continue.")
    if st.button("Continue"):
        st.session_state["page"] = "positions"

def position_board():
    st.write("### Pick a detailed position")
    cols = st.columns(6)
    for i, pos in enumerate(DETAILED_POSITIONS):
        if cols[i % 6].button(pos, use_container_width=True, key=f"pos_{pos}"):
            st.session_state["sel_subpos"] = pos
            st.session_state["group"] = SUBPOS_TO_GROUP[pos]
            st.session_state["page"] = "archetype"
    st.text_input("Bearer Token (optional)", key="bearer_token", value=st.session_state.get("bearer_token",""))

def archetype(subpos: str):
    st.write(f"### {subpos} — Archetypes")
    archs = ARCHETYPES_BY_SUBPOS.get(subpos, [])
    if not archs:
        archs = ["All-Round"]
    sel = st.radio("Choose an archetype", archs, horizontal=True, key=f"arch_{subpos}")
    if st.button("Next → Traits"):
        st.session_state["sel_arch"] = sel
        st.session_state["page"] = "traits"

def traits_flow(group: str, subpos: str, arch: str, data_map: Dict[str, pd.DataFrame]):
    st.write(f"### {subpos} · {arch} — Traits & Filters")
    trait_options = TRAITS_BY_ARCH.get(arch, [])
    chosen_traits = st.multiselect("Traits to emphasize", trait_options, default=trait_options)
    age_min, age_max = st.slider("Age range", 16, 40, (18, 30))
    budget = st.number_input("Max budget (€)", min_value=0, value=50_000_000, step=1_000_000)
    topk = st.number_input("Top K results", min_value=1, max_value=50, value=3, step=1)

    df = data_map[group].copy()
    if "Position" in df.columns:
        mask = df["Position"].astype(str).str.upper().str.contains(subpos.upper()) | (df["Position"].astype(str).str.upper() == group.upper())
        df = df[mask]

    df = df[(df["Age"].fillna(100).between(age_min, age_max)) & (df["Value"].fillna(10**9) <= budget)]
    ranked = score_players(df, chosen_traits)
    st.write("#### Results")
    if ranked.empty:
        st.info("No players match filters. Try loosening filters or check Position labels in your Excel.")
        return

    for i, row in ranked.head(int(topk)).reset_index(drop=True).iterrows():
        key_base = f"{subpos}_{arch}_{i}"
        st.markdown(f"""
<div class="card">
<b>#{i+1} — {row.get('Player','Unnamed')}</b> <span class="badge">Score: {row['Score']:.3f}</span>
<br><span class="small">Age: {int(row.get('Age',0))} • Position: {row.get('Position','-')} • Value: €{int(row.get('Value',0)):,}</span>
</div>
""", unsafe_allow_html=True)
        with st.expander(f"Twitter sentiment for {row.get('Player','Unnamed')}"):
            if st.button("Analyze sentiment", key=f"btn_{key_base}"):
                try:
                    show_sentiment(str(row.get("Player","")))
                except Exception as e:
                    st.markdown(f'<div class="warn">Sentiment failed: {str(e)}</div>', unsafe_allow_html=True)

    st.download_button(
        "Download results (CSV)",
        data=ranked.to_csv(index=False).encode("utf-8"),
        file_name=f"scouting_{subpos}_{arch.replace(' ','_').lower()}.csv",
        mime="text/csv"
    )

def main():
    header()
    if "bearer_token" not in st.session_state:
        st.session_state["bearer_token"] = ""
    page = st.session_state.get("page", "welcome")
    data_map = load_all()

    if page == "welcome":
        welcome()
    elif page == "positions":
        position_board()
    elif page == "archetype":
        subpos = st.session_state.get("sel_subpos", "CB")
        archetype(subpos)
    elif page == "traits":
        subpos = st.session_state.get("sel_subpos", "CB")
        group = st.session_state.get("group", SUBPOS_TO_GROUP.get(subpos, "DF"))
        arch = st.session_state.get("sel_arch", ARCHETYPES_BY_SUBPOS.get(subpos, ["All-Round"])[0])
        traits_flow(group, subpos, arch, data_map)

if __name__ == "__main__":
    main()
